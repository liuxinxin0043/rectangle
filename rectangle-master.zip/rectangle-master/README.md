# rectangle
计算矩形的面积和周长
